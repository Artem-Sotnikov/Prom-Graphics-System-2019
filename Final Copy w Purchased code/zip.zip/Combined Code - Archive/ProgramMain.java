public class ProgramMain {
 public static void main(String args[]) throws Exception{
  TicketingSystem system = new TicketingSystem();
}
}